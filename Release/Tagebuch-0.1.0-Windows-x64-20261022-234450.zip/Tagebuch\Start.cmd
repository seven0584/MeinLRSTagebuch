@echo off
cd /d "%~dp0"
"runtime\node.exe" "scripts\start.cjs"
if errorlevel 1 pause
