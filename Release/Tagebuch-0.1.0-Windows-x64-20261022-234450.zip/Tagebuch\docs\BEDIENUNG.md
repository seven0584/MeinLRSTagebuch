# Bedienung

## Hilfe für Kinder

Schreibe im Schreibblock über deinen Tag. Die Fragen daneben sind freiwillig; ein Wort oder ein Emoji reicht. Du musst nichts erzählen, das du nicht erzählen möchtest.

Mit **Prüfen** schaust du dir deinen Text an. Wähle eine markierte Stelle aus und bearbeite sie direkt im Schreibblock. Die Lernhilfe kann einen Hinweis erklären oder eine mögliche Schreibweise zeigen. Sie kann sich auch irren. Ist ein Wort ein Name, kannst du ihn bestätigen. Du darfst eine schwierige Stelle für heute offenlassen. Mit **Für heute abschließen** speicherst du deinen Text auch mit offenen Hinweisen. Du musst nicht alles allein lösen. Auch dann bekommst du deine normale Belohnung.

Wenn dein Eintrag fertig ist und die Gefühlsübersicht eingeschaltet ist, öffnet sich ein Fenster mit einer persönlichen Ermutigung. Wähle dort ein bis drei Gefühle und dann **Eintrag speichern**. Mit **Zurück zum Text** kannst du weiterarbeiten. Deine Eltern sehen diese Auswahl und gegebenenfalls getrennte KI-Hinweise aus deinem freien Text. Deine Antworten auf die Tagesfragen bleiben privat. Nach dem Speichern führen **Deinen Text nochmal lesen** und **Spielen** direkt in die passende Ansicht.

Wenn deine Eltern die Online-Lernhilfe mit OpenAI eingeschaltet haben, wird dein Text beim Prüfen und beim Anfordern von KI-Hilfe an OpenAI geschickt.

Unter **Lesen** findest du deine gespeicherten Einträge. **Üben**, **Spiel** und **Shop** öffnen die zusätzlichen Angebote. Deine PIN schützt den Zugang zu deinem Tagebuch. Frage deine Eltern, wenn du sie vergessen hast.

## Einrichtung

**Aktuelle Windows-Dev:** Im Projektordner `npm run dev` starten und `http://127.0.0.1:8765` öffnen. Die App verwendet automatisch den Ordner `data/` im Projekt. Eine Ordnerauswahl und eine Browser-Freigabe sind dafür nicht nötig. Der vollständige Pfad steht unter **Eltern → Einstellungen → Speicherort**. Nach Änderungen am Dev-Server diesen mit Strg+C beenden, erneut starten und die Browserseite neu laden.

Vorhandene Daten im Browser desselben Ursprungs werden beim ersten Verbinden in den leeren automatischen Speicher übernommen. Aus einer bisher direkt geöffneten HTML-Datei übernimmt man die Daten über **Sicherung herunterladen** und anschließend **Sicherung wiederherstellen** in der neuen Dev-Seite. Verschiedene Browser-Ursprünge können nicht automatisch aufeinander zugreifen. Das neue `data/` und der alte Tagebuch-Ordner werden nicht automatisch synchronisiert.

**Bisherige Datei-/ZIP-Version:** Für diese gilt weiterhin die folgende Einrichtung mit Ordnerauswahl:

Das ZIP aus `Release/` vollständig entpacken und `Tagebuch.html` aus dem entpackten Ordner mit Chrome oder Edge am PC öffnen. Alle Dateien unter `app/` müssen daneben liegen. Den ganzen Ordner an einem festen Platz behalten; die App speichert bei freigegebenem Ordner direkt dort.

Beim ersten Start den Tagebuch-Ordner wählen und Bearbeiten zulassen. Fragt der Browser nach einem Neustart erneut, den Zugriff wieder erlauben. Falls angeboten, kann die Erlaubnis für weitere Besuche gespeichert werden.

Im Elternbereich eine PIN mit vier bis acht Ziffern festlegen und Kinder anlegen. Die Einstellungen für Ziele, Übungen, Belohnungen und Spielzeit gelten für das jeweils ausgewählte Kind. Die Kinder legen eigene PINs fest.

## Schreiben und Lesen

Ein Kind auf der Startseite auswählen und mit seiner PIN öffnen. Im aktuellen Dev-Stand steht **Prüfen** direkt über dem Schreibblock; nach Änderungen heißt die Aktion **Nochmal prüfen**. Markierte Stellen werden im Schreibblock hervorgehoben und lassen sich dort direkt bearbeiten. Hinweise und freiwilliger Tagesrückblick stehen auf breiten Bildschirmen rechts daneben, ohne den Text noch einmal anzuzeigen. Auf schmalen Bildschirmen werden die Bereiche untereinander angeordnet. Bekannte Namen können aufgenommen werden, damit sie nicht ständig als Rechtschreibfehler erscheinen.

Beim Prüfen arbeiten Wörterbuch und lokale Regeln sowie bei eingeschalteter Online-Grammatikprüfung LanguageTool. Ist die lokale Ollama-Lernhilfe eingeschaltet, prüft Ollama zusätzlich höchstens die ersten 1.800 Zeichen des Freitexts im Zusammenhang: Welche Markierungen sind echte Rechtschreibfehler, könnte eine Stelle ein Name sein, wurden eindeutige Fehler übersehen? Unsichere Ergebnisse dürfen offenbleiben. **Ohne KI weiter** beendet diese zusätzliche Prüfung; bei einem technischen Fehler bleiben die normalen Prüfhinweise erhalten. Rückblickantworten und die selbst ausgewählten Gefühle gehören nicht zu dieser Rechtschreibprüfung. Weitere Erklärungen lassen sich an der einzelnen Stelle anfordern. Die getrennte Gefühlsauswertung kann bei entsprechender Eltern-Einstellung zusätzlich beim Speichern des Freitexts anlaufen (siehe unten).

Ein gemaltes Bild kann den Eintrag ergänzen. Den Eintrag über den Abschluss der Schreibansicht speichern; die Leseansicht zeigt die bisherigen Einträge. Schreibziele werden im Elternbereich festgelegt. Die Prüfung ist eine Lernhilfe und kann richtige Wörter markieren oder Fehler übersehen.

Unter dem Schreibblock stehen keine zusätzlichen Fehler- oder Eintragslisten. Gespeicherte Texte sind über **Lesen** erreichbar. Unter **Üben** gibt es Aufgaben zu Fehlermustern sowie Diktate. Für die Sprachausgabe muss im Browser beziehungsweise Betriebssystem eine geeignete deutsche Stimme verfügbar sein.

## Freiwilliger Tagesrückblick im Dev-Stand

Rechts stehen **Was war heute schön?**, **Wie fühlst du dich gerade?** und **Was wünschst du dir für morgen?** Zur Frage **Was war heute schwierig?** und zur bisherigen Lernfrage kann man weitere Felder aufklappen. Alle Antworten sind freiwillig: Ein Wort oder Emoji reicht, und auch ein schöner Moment muss nicht genannt werden. Ein reiner Tagesrückblick lässt sich über **Antworten speichern** ohne Mindestumfang des Tagesauftrags speichern. Wenn zusätzlich ein freier Text geschrieben wird, gelten dafür weiterhin die eingestellten Schreibziele; Antworten können zum Umfang beitragen. Bei eingeschalteter Gefühlsübersicht ist vor dem Speichern zusätzlich die Auswahl von ein bis drei Gefühlen nötig, auch bei einem reinen Rückblick. Die Rückblickfragen selbst bleiben freiwillig.

Die Antworten werden weder mit dem Wörterbuch noch mit LanguageTool, Ollama oder OpenAI geprüft. Sie erhalten keine sprachliche Bewertung und werden in der normalen Elternübersicht nicht angezeigt. Frühere Einträge behalten ihre damaligen Fragenbeschriftungen.

Solche Fragen können ein Gespräch eröffnen; sie sind kein Test und keine Therapie. Aktives Zuhören und konkrete offene Fragen werden etwa von [UNICEF](https://www.unicef.org/lac/en/parenting-lac/nurturing-care/how-communicate-effectively-young-child) und [Seattle Children’s](https://www.seattlechildrens.org/healthy-tides/getting-beyond-how-was-your-day/) empfohlen. Daraus folgt keine nachgewiesene Wirkung dieser App. Die Schlafenszeit kann für manche Kinder ein ruhiger Gesprächsmoment sein, ist aber keine Pflicht. Sorgen, die wach halten, besser schon tagsüber in Ruhe besprechen; darauf weist [Newcastle Hospitals NHS](https://www.newcastle-hospitals.nhs.uk/services/great-north-childrens-hospital/childrens-sleep-service/sleep-older-children/) hin. Die App ersetzt weder ein Gespräch noch verlangt sie die Nutzung eines Bildschirms direkt vor dem Einschlafen.

## Gefühlsauswahl und Elternübersicht im Dev-Stand

Die Gefühlsübersicht und zusätzliche lokale KI-Hinweise sind im aktuellen Dev-Stand standardmäßig eingeschaltet. Unter **Eltern → Einstellungen → Prüfung & Lernhilfe** lassen sich beide über getrennte Schalter ändern. Die KI läuft nur, wenn außerdem die lokale Lernhilfe mit einem installierten Ollama-Modell eingeschaltet ist.

Bei eingeschalteter Gefühlsübersicht erscheint die Auswahl erst beim endgültigen Abschluss als Popup, mit einer persönlichen Ermutigung wie „Klasse gemacht, Susi!“. Das Kind wählt dort ein bis drei Gefühle und bestätigt **Eintrag speichern**. Vorher ist noch kein Eintrag gespeichert. **Zurück zum Text** oder Escape lässt den Entwurf erhalten. Das Prüfen des Haupttexts erfordert diese Auswahl noch nicht. Die Palette umfasst 🙂 fröhlich, 😎 stolz, 😍 geliebt, 🙏 dankbar, 😌 ruhig, 🤩 aufgeregt, 😴 müde, 😢 traurig, 😠 wütend, 😟 besorgt, 😵 überfordert, 😔 einsam und 🤷 weiß nicht. Gegensätzliche Gefühle sind möglich. Ein Hinweis erklärt dem Kind, dass die Eltern die Auswahl und gegebenenfalls KI-Hinweise sehen; der Tagebuchtext und die Antworten auf die Rückblickfragen werden ihnen nicht angezeigt. Nach dem Speichern führen **Deinen Text nochmal lesen** und **Spielen** direkt in die jeweilige Ansicht.

Die KI-Auswertung startet nach dem Speichern im Hintergrund und betrachtet höchstens 1.800 Zeichen des freien Haupttexts. Sie erhält weder die Gefühlsauswahl des Kindes noch seine Rückblickantworten. Ältere Einträge werden nicht nachträglich durchsucht. Ohne Freitext entsteht kein KI-Eindruck. Fehler oder Zeitüberschreitungen verhindern das Speichern nicht; in der Elternübersicht zeigt der KI-Status zunächst die laufende Auswertung und bei einem Fehler deren Fehlschlag. Wird die Seite vor Abschluss neu geladen, wird die unterbrochene Auswertung als fehlgeschlagen gekennzeichnet. Es gibt keinen Knopf zur erneuten Auswertung alter Einträge.

Die Hauptseite **Übersicht** zeigt kompakt **Heute** und den **Gesamtdurchschnitt**, jeweils getrennt nach Kind und KI. Pro Quelle werden die bis zu drei häufigsten Gefühle gezeigt. Über **Zur Gefühlsübersicht** oder den Hauptmenüpunkt **Gefühle** erreicht ihr die vollständige Anzeige mit allen Gefühlen, Zeitraumwahl und KW-Kalender. Der KI-Eindruck ist eine unsichere Interpretation des Texts, keine Feststellung des tatsächlichen Gefühls und keine Diagnose. Die Auswahl **Heute** und **Durchschnitt · alle Tage** kann direkt verwendet werden. **Letzte volle Woche** und **Letzter voller Monat** sind erst nach einem seit Beginn der Gefühlsaufzeichnung vollständig abgedeckten Kalenderzeitraum verfügbar. Wochen laufen Montag bis Sonntag. Bei einem Start am Mittwoch zählt erst die folgende vollständige Woche; die erste Wochenübersicht steht am darauf folgenden Montag bereit. Entsprechendes gilt bei einem Start mitten im Monat. Einzelne Tage dürfen fehlen.

Die Prozentwerte rechnen je Gefühl und Quelle mit den tatsächlich erfassten Tagen: drei von fünf Tagen ergeben 60 %. Mehrere Einträge am selben Tag erhöhen dessen Gewicht nicht. Mehrfachgefühle bleiben erhalten, deshalb können die Prozentwerte zusammen über 100 % liegen. Fehlende Angaben gelten nicht als neutral; positive und negative Gefühle werden nicht gegeneinander verrechnet. Der aufklappbare Gefühlskalender zeigt Tageswerte von Montag bis Sonntag für die aktuelle und bis zu sieben frühere Kalenderwochen mit Einträgen, einschließlich Kalenderwochennummer und zugehörigem ISO-Jahr. Einzelne Tage der laufenden Woche sind dort bereits sichtbar. Tagebuchtexte erscheinen auch dort nicht.

## OpenAI-Lernhilfe einrichten

Die Windows-Dev kann alternativ ChatGPT-Modelle über die **OpenAI-API** verwenden. Ein ChatGPT-Pro-, Plus- oder Free-Konto stellt dafür kein API-Guthaben bereit. API-Nutzung wird separat beim API-Konto abgerechnet. Ein API-Schlüssel wird ausschließlich im Elternbereich eingerichtet; ihn nicht in einen Tagebucheintrag, eine Chat-Nachricht oder eine Sicherung einfügen.

1. Den lokalen App-Server mit `npm run dev` starten beziehungsweise nach einem Update neu starten und die Seite neu laden.
2. Unter **Eltern → Einstellungen → Prüfung & Lernhilfe → Lernhilfe auswählen** die Option **Online mit OpenAI (ChatGPT-Modelle)** wählen.
3. Den API-Schlüssel im Passwortfeld einfügen, ein Modell auswählen und **Schlüssel und Modell speichern** wählen. Ein leeres Schlüsselfeld lässt einen vorhandenen Schlüssel unverändert. Der gespeicherte Schlüssel wird niemals erneut angezeigt.
4. **OpenAI-Beispiel testen** wählen. Die App prüft ausschließlich einen erfundenen Satz. Es werden keine Tagebuchdaten benutzt; API-Kosten können trotzdem entstehen. So lassen sich Zugang, Modell und Antwortformat vor der Freigabe prüfen.
5. Die Voraussetzungen für Kindertexte klären. OpenAI verlangt für personenbezogene Daten von Kindern unter 13 beziehungsweise unter dem geltenden digitalen Einwilligungsalter **Zero Data Retention**. Die Freischaltung muss OpenAI für das API-Konto erteilen. Die Checkbox in der App bestätigt diese bestehende Freischaltung; sie aktiviert und überprüft sie nicht. Ohne diese Voraussetzung bleibt der synthetische Beispieltest nutzbar, Kindertexte bleiben gesperrt. Siehe [OpenAI-Vorgaben für Minderjährige](https://developers.openai.com/api/docs/guides/safety-checks/under-18-api-guidance).
6. Erst danach beide Freigaben für die Online-Verarbeitung und die bereits bestehende ZDR-Freischaltung setzen und **Lernhilfe speichern** wählen.

Bei ausgewähltem OpenAI sendet **Prüfen** den Haupttext bis höchstens 12.000 Zeichen an OpenAI. Längere Texte werden nicht still gekürzt; stattdessen erscheint ein Hinweis und die übrige Prüfung bleibt nutzbar. Eine zusätzlich angeforderte Erklärung erhält die betroffene Stelle und einen begrenzten Verlauf der laufenden Lernhilfe. Rückblickantworten, Gefühlsauswahl und andere Einträge werden nicht angehängt. Persönliche Informationen, die das Kind selbst in den Haupttext schreibt, sind natürlich Teil dieses Textes. Die OpenAI-Anbindung erstellt keine Gefühlsauswertung für Eltern. Die Elternansicht erhält weiterhin keinen Tagebuchtext.

Beim Austausch eines API-Schlüssels über **Schlüssel und Modell speichern** werden bestehende Kinderfreigaben zurückgesetzt. Zum Zurücknehmen einer Freigabe den Haken entfernen und **Lernhilfe speichern** wählen; der Schlüssel kann dabei gespeichert bleiben.

OpenAI benötigt eine Internetverbindung. Bei Fehlern oder fehlender Freigabe bleiben die normale Prüfung und der Abschluss mit offenen Hinweisen möglich; die App wechselt nicht automatisch zu einem anderen KI-Anbieter. **Schlüssel entfernen** löscht den Zugang beim lokalen App-Server und schaltet OpenAI aus. Der Schlüssel gehört weder in den Browser-Familienzustand noch in die Tagebuch-Sicherung. Beim Gerätewechsel ist er neu einzurichten. Die direkt geöffnete HTML-Datei unterstützt diese Anbindung nicht; erforderlich ist der lokale App-Server.

## Zusätzliche lokale Lernhilfe im Dev-Stand

Diese Funktion steht im aktuellen Quellstand unter `Dev/`, noch nicht im bisherigen ZIP-Release. Sie ist zunächst ausgeschaltet. Die bestehende Online-Grammatikprüfung ist eine davon unabhängige Einstellung.

1. Mit Node.js im Projektordner `npm run dev` starten und `http://127.0.0.1:8765` in Chrome oder Edge öffnen. Eine gesonderte Ollama-Installation ist nicht nötig. Die automatische Einrichtung unterstützt Windows x64 und ARM64.
2. Im Elternbereich unter **Einstellungen → Prüfung & Lernhilfe** ein Sprachmodell auswählen. Angeboten werden Qwen 3 mit 4B Instruct (`qwen3:4b-instruct-2507-q4_K_M`, ca. 2,5 GB), Qwen 3 mit 8B (ca. 5,2 GB) und Gemma 3 mit 4B (ca. 3,4 GB). Downloadgrößen sind ungefähr und keine RAM-Anforderungen. Es sind Kandidaten zum Ausprobieren, keine pädagogisch geprüften Modelle. Modellseite und Lizenz sind direkt verlinkt. Reine Thinking-Modelle werden nicht angeboten; falls ein solches Modell bereits eingestellt ist, zeigt die App einen Hinweis zur Auswahl einer passenden Variante.
3. **Lokale KI und Modell herunterladen** wählen. Beim ersten Mal kommt die Ollama-Laufzeit hinzu (x64 ca. 1,6 GB, ARM64 ca. 0,21 GB Download; mehrere GB Platz zum Entpacken freihalten). Die Fortschrittsanzeige zeigt die aktuelle Phase. Den lokalen Server währenddessen laufen lassen. Nach einem Seitenneuladen wird der Fortschritt wieder angezeigt. Nach Fehlern erneut auf den Knopf drücken; fertige Laufzeiten bleiben erhalten. **Installierte Modelle suchen** zeigt zusätzlich weitere bereits im App-Speicher vorhandene lokale Textmodelle, ohne Cloud- und reine Embedding-Modelle.
4. **Beispiel testen** wählen. Die App fragt mit einem erfundenen Satz nach einer Erklärung. Prüft selbst, ob die Antwort richtig und für euer Kind verständlich ist; eine erfolgreiche Verbindung beweist das nicht.
   **Kompatibel · Prozessor verwenden** ist voreingestellt. Beim Einschalten der Grafikbeschleunigung testet die App das ausgewählte Modell mit zwei aufeinanderfolgenden Beispielen. Beide Antworten müssen verwendbar sein und die erwarteten Wörter verbessern; außerdem muss Ollama echte Nutzung des Grafikspeichers melden. Schlägt das fehl, erscheint eine Meldung und **Kompatibel** wird ausgewählt. Im späteren Betrieb versucht die Lernhilfe nach einer unbrauchbaren Antwort dasselbe Modell einmal auf dem Prozessor; die gespeicherte Einstellung bleibt dabei unverändert.
   **Modell automatisch auswählen** vergleicht die geeigneten, bereits heruntergeladenen Modelle jeweils auf Prozessor und Grafikbeschleunigung. Jede Variante beantwortet dieselben zwei Fragen nacheinander; es laufen keine konkurrierenden Testanfragen. Nur bestandene Varianten zählen. Die schnellste mittlere Antwortzeit gewinnt, wobei die gemeldete Modellladezeit abgezogen wird. Die Tabelle zeigt Ergebnisse und Fehler. **Test abbrechen** beendet den Vergleich. Es werden dabei keine Modelle heruntergeladen und keine Tagebuchtexte verwendet. Die gewonnene Auswahl anschließend speichern. Zwei bestandene Beispiele beweisen keine allgemeine fachliche oder pädagogische Qualität.
5. **Lokal auf diesem PC mit Ollama** auswählen und **Lernhilfe speichern** wählen. Für diese Einstellungen ist kein ChatGPT-Abo nötig.

Die App lädt eine festgelegte offizielle [Ollama-Standalone-Version](https://docs.ollama.com/windows#standalone-cli), prüft die SHA-256-Prüfsumme und entpackt sie nach `data/ai/`. Modelle liegen in `data/ai/models/`. Weder PATH noch globale Windows-Einstellungen werden geändert. Eine vorhandene Ollama-Installation und ihre Modelle werden nicht übernommen oder verändert. Beim ersten Zugriff nach einem App-Neustart startet die Laufzeit automatisch im Hintergrund; beim regulären Beenden des Servers mit Strg+C wird sie beendet. Nach der Einrichtung kann die Lernhilfe offline arbeiten. Bei Problemen freien Speicher, Windows-Version und Treiber prüfen. Der Dev-Start benötigt weiterhin Node.js; ein fertiges Windows-Installationspaket wird hierdurch noch nicht erzeugt. Direktes Öffnen der HTML-Datei kann keine KI-Laufzeit herunterladen oder starten.

Das Kind tippt nach dem Prüfen auf eine markierte Stelle. Eindeutige Groß-/Kleinschreibhinweise erklärt die App direkt aus ihrer lokalen Regel. Bei bestätigten Zusammenziehungen kann ein Vorschlag aus zwei Wörtern bestehen, etwa „weißt du“; die Hilfe erklärt dann auch das Leerzeichen.

Die Zusatzhilfe bietet **Erkläre mir die Stelle**, **Das verstehe ich noch nicht** und **Zeig mir einen Vorschlag**. Ein zusätzliches Fragefeld gibt es nicht. Bei eindeutig zuordenbaren Änderungen berücksichtigt die Hilfe den aktuellen Text, vorherige Versuche und bisherige Erklärungen direkt. Lässt sich die ausgewählte Stelle nach einer Änderung nicht mehr zuordnen, fordert die App zum erneuten Prüfen auf. Ein Vorschlag wird nicht automatisch in den Text übernommen und gilt nicht automatisch als richtig. Nach mehreren Textänderungen können alte Markierungen nicht mehr zugeordnet werden; dann bitte **Nochmal prüfen** verwenden. Nicht zuordenbare Altmarken und Erklärungen zu einem inzwischen anderen Wort werden nicht angezeigt.

Für einfache, geprüfte Buchstabenänderungen formuliert die App den Hinweis direkt aus dem Vergleich der Schreibweisen. So lässt sich etwa ein überzähliges e konkret benennen. Das vermeidet erfundene Buchstabierungen; die vorgeschlagene Wortbedeutung kann trotzdem falsch sein. Bei geprüften Vorschlägen mit zwei oder drei Buchstabenänderungen nennt die App die Anzahl der Stellen ausdrücklich. Dabei zählt die Großschreibung als eigene Änderung und eine benachbarte Vertauschung als eine Änderung. Das ist keine sichere Zahl sprachlicher Fehler, sondern ein nachvollziehbarer Vergleich der beiden Schreibweisen.

Nach einer Prüfung steht **Für heute abschließen** direkt bei den Hinweisen. Das Kind darf alle verbleibenden Hinweise auf einmal offenlassen und seinen aktuellen Text speichern. Auch nach Änderungen ist dafür keine weitere Prüfung nötig; die Abschlussmeldung sagt dann, dass die letzten Änderungen noch nicht geprüft sind. Die App erklärt offen, dass sie nicht jede Stelle sicher prüfen kann und ihre Hinweise falsch sein können. **Für heute offenlassen** bleibt zusätzlich bei einzelnen Markierungen verfügbar. Die Gefühlsauswahl bleibt beim Speichern verpflichtend, falls sie eingeschaltet ist. Offene Hinweise schmälern die normalen Belohnungen nicht. Auch ohne weitere Hinweise verspricht die Abschlussmeldung keine Fehlerfreiheit. Die separaten Diktatübungen sind nicht verändert.

**Daten:** Die zusätzliche Prüfung nach **Prüfen** erhält höchstens 1.800 Zeichen Freitext und bis zu 20 darin liegende markierte Wörter mit ihren Vorschlägen. Für eine einzelne Erklärung werden ein begrenzter Satzausschnitt um die markierte Stelle, der Prüfhinweis, bis zu drei vorherige Versuche, zwei vorherige Erklärungen an Ollama auf diesem PC gegeben. Rückblickantworten, Gefühlsauswahl, andere Einträge und die restliche Familienhistorie werden dafür nicht angehängt. Gesprächsverläufe liegen nur in der laufenden Sitzung; im Eintrag wird lediglich vermerkt, ob Hilfe verwendet oder etwas offengelassen wurde. Die App lehnt erkannte Cloud-Modelle ab und startet die eigene Laufzeit mit `OLLAMA_NO_CLOUD=1`. Downloads kontaktieren GitHub und die Ollama-Modellregistrierung; dabei werden keine Tagebuchtexte übertragen. Die oben genannte Online-Grammatikprüfung sendet bei Aktivierung weiterhin Text an LanguageTool.

## Elternbereich

Eltern sehen Zahlen, Lernaktivitäten und Fehlerarten; die normale Elternansicht zeigt keine Tagebuchtexte. Dort lassen sich unter anderem Schreib- und Leseziele, Belohnungen, Spielzeit, Pausentage und Joker einstellen. Belohnungswünsche des Kindes können angenommen oder abgelehnt werden.

Die Einstellungen im Dev-Stand führen durch sechs Schritte: **Speicher & Sicherung**, **Kinderprofile**, **Tagesauftrag**, **Prüfung & Lernhilfe**, **PINs** und die optionale **Wartung**. Die aufklappbaren Unterpunkte **1–6** links unter **Einstellungen** öffnen jeden Schritt direkt. **Weiter** wechselt nur die Ansicht. Änderungen werden über die jeweils beschrifteten Aktionen gespeichert; Schalter wirken direkt. Die Übersicht bleibt der Einstieg für den Überblick über Lernaktivitäten.

Kurze Hinweise erklären die jeweilige Entscheidung direkt am Feld. Über **?** öffnet ihr die ausführliche Erklärung zum Thema, ohne die Einstellungen zu verlassen. Datenschutz- und Sicherungshinweise bleiben kurz sichtbar. Die Hauptseite **Hilfe** enthält weiterhin die vollständige Anleitung.

**Belohnungen** hat aufklappbare Unterpunkte im linken Menü: **Einkäufe**, **Coins**, **Shop**, **Spielzeit**, **Pausen** und **Joker**. So seht ihr jeweils nur die passenden Eingaben. Unter **Coins** stehen Kontostand, manuelle Buchungen, Coin-Regeln und Verlauf. Änderungen an Monatsmenge und Spargrenze der Joker werden direkt gespeichert. Die Übersichtskarte für offene Einkäufe öffnet direkt **Einkäufe**. Ein Wechsel des Unterpunkts speichert keine Änderungen.

Eine vergessene Kinder-PIN kann im Elternbereich zurückgesetzt werden. Das Kind sieht danach einen Hinweis und legt eine neue PIN fest. Das bedeutet auch, dass die PIN keine Zugriffssperre gegen Personen mit Kontrolle über den PC ist.

## Online-Funktionen

Die zusätzliche Grammatikprüfung lässt sich in den Eltern-Einstellungen ausschalten. Sie ist anfangs eingeschaltet und sendet beim Prüfen den Text an LanguageTool. Ohne Internet oder bei einem Fehler des Dienstes bleibt die lokale Prüfung verfügbar.

Für Benachrichtigungen einen ntfy-Kanal einrichten und am Handy abonnieren; die App bietet dafür einen Link beziehungsweise QR-Code und eine Testnachricht. Der Kanalname sollte nicht öffentlich geteilt werden. Benachrichtigungen können Namen und Aktivitäten des Kindes enthalten.

## Sicherung und Umzug

Im Elternbereich eine Sicherung mit einem Kennwort erstellen und die heruntergeladene Datei an einem sicheren Ort aufbewahren. Das Kennwort wird für die Wiederherstellung benötigt. Die App verlangt mindestens sechs Zeichen; ein längeres Kennwort ist sinnvoll.

Für einen Umzug im Ordnerbetrieb den ganzen Tagebuch-Ordner einschließlich `config/` und `kinder/` kopieren. Auf dem neuen PC die HTML-Datei öffnen und diesen Ordner freigeben. Eine Sicherung vor dem Umzug aufbewahren. Eine Wiederherstellung aus einer Sicherungsdatei ersetzt den aktuellen Browserstand; vorher den vorhandenen Stand sichern. Näheres zu den Grenzen der Sicherungen steht unter [Daten und Speicherung](DATEN-UND-SPEICHERUNG.md).

## Wenn etwas nicht funktioniert

| Problem | Nächster Schritt |
| --- | --- |
| Gestaltung oder Funktionen fehlen | Das komplette ZIP entpacken und die Ordnerstruktur neben `Tagebuch.html` erhalten. |
| Ordner lässt sich nicht auswählen | Chrome oder Edge am PC verwenden; alternativ nur im Browser speichern und regelmäßig Sicherungen herunterladen. |
| Ordnerzugriff pausiert | Auf der Startseite oder im Elternbereich den Zugriff erneut erlauben. |
| Speichern fehlgeschlagen | Im Elternbereich Speicherstatus, Browser-Erlaubnis und Schreibzugriff auf den Ordner prüfen. |
| Diktat bleibt stumm | Deutsche Systemstimme und Audioausgabe prüfen. |
| Online-Prüfung liefert keine Hinweise | Internet und Einstellung prüfen; die lokale Prüfung funktioniert weiterhin. |
| ntfy-Nachrichten fehlen | Kanal-Link im Handy-Browser öffnen, Kanalname vergleichen und Benachrichtigungsrechte der Handy-App prüfen. |

Browserdaten nicht zum Testen löschen, solange keine Sicherung vorliegt. Die Funktion zum Löschen aller Browserdaten entfernt auch Profile, Einträge, Bilder und PINs aus dem Browser. Dateien im Tagebuch-Ordner bleiben dabei bestehen.
